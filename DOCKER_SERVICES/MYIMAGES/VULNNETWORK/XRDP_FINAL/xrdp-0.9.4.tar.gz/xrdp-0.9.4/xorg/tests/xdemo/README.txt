
this is a program to test xwindows

