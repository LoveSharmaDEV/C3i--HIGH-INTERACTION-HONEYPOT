# automatically generated file - see ../scripts/reversion
EXIM_RELEASE_VERSION="4.92"
EXIM_COMPILE_NUMBER="1"
