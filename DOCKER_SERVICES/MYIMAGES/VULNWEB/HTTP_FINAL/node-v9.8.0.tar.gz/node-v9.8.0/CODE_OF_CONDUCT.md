# Code of Conduct

The Node.js Code of Conduct document has moved to
https://github.com/nodejs/admin/blob/master/CODE_OF_CONDUCT.md. Please update
links to this document accordingly.

The Node.js Moderation policy can be found at
https://github.com/nodejs/admin/blob/master/Moderation-Policy.md
